export class clsEmployee{
    firstName:string ; 

}